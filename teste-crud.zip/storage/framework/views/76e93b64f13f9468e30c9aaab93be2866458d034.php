<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            Editar <?php echo e($user->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div>
        <div class="max-w-4xl mx-auto py-10 sm:px-6 lg:px-8">
            <div class="block mb-8">
                <a href="<?php echo e(route('users.index')); ?>" class="bg-yellow-500 hover:bg-white hover:text-yellow-500 text-white font-bold py-0 px-2 rounded">< Voltar</a>
            </div>
            <div class="mt-5 md:mt-0 md:col-span-2 ">
                <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="shadow overflow-hidden sm:rounded-md bg-black">
                        <div class="px-4 py-5 bg-black sm:p-6">
                            <label for="name" class="block font-black text-sm text-white">Nome</label>
                            <input type="text" name="name" id="name" class="bg-gray-900 text-white form-input rounded-md shadow-sm mt-1 block w-full"
                                   value="<?php echo e(old('name', $user->name)); ?>" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="px-4 py-5 bg-black sm:p-6">
                            <label for="email" class="block font-black text-sm text-white">Email</label>
                            <input type="email" name="email" id="email" class="bg-gray-900 text-white form-input rounded-md shadow-sm mt-1 block w-full"
                                   value="<?php echo e(old('email', $user->email)); ?>" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="px-4 py-5 bg-black sm:p-6">
                            <label for="password" class="block font-black text-sm text-white">Senha</label>
                            <input type="password" name="password" id="password" class="bg-gray-900 text-white form-input rounded-md shadow-sm mt-1 block w-full" />
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="px-4 py-5 bg-black sm:p-6">
                            <label for="roles" class="block font-black text-sm text-white">Roles</label>
                            <select name="roles[]" id="roles" class="bg-gray-900 text-white form-multiselect block rounded-md shadow-sm mt-1 block w-full">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($role != "Cliente" && $role != "Acessor"): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('adm_access')): ?>
                                            <option value="<?php echo e($id); ?>"<?php echo e(in_array($id, old('roles', [])) ? ' selected' : ''); ?>><?php echo e($role); ?></option>
                                        <?php endif; ?>    
                                    <?php endif; ?>
                                    <?php if($role == "Cliente"): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendedor_access')): ?>
                                        <option selected value="<?php echo e($id); ?>"<?php echo e(in_array($id, old('roles', [])) ? ' selected' : ''); ?>><?php echo e($role); ?></option>
                                        <?php endif; ?>    
                                    <?php endif; ?>
                                    <?php if($role == "Acessor"): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendedor_access')): ?>
                                        <option  value="<?php echo e($id); ?>"<?php echo e(in_array($id, old('roles', [])) ? ' selected' : ''); ?>><?php echo e($role); ?></option>
                                        <?php endif; ?>    
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="shadow flex items-center justify-end px-4 py-3 bg-black text-right sm:px-6 border-t border-gray-900">
                            <button class="inline-flex items-center px-4 py-2 bg-green-500 border border-transparent rounded-md font-black text-xs text-white uppercase tracking-widest hover:text-green-500 hover:bg-white active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:shadow-outline-gray disabled:opacity-25 transition ease-in-out duration-150">
                                Editar
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\gusta\OneDrive\Desktop\teste-crud\resources\views/users/edit.blade.php ENDPATH**/ ?>