<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('header'); ?> 
      <h2 class="font-extrabold text-xl text-white leading-tight">
         Editar Pagamentos (Contrato #<?php echo e($contrato->id); ?>)
      </h2>
    <?php $__env->endSlot(); ?>
   <div>
      <div class="max-w-4xl mx-auto py-10 sm:px-6 lg:px-8">
         <div class="my-10 md:mt-0 md:col-span-2 w-full text-lg text-center font-bold bg-green-500 text-white ">
            <?php if(isset($_GET['message'])): ?>
            <?php echo e($_GET['message']); ?>

            <?php endif; ?>
         </div>
            <div class="block mb-8">
                <a href="<?php echo e(route('pagamentos.show', $contrato)); ?>" class="bg-yellow-500 hover:bg-white hover:text-yellow-500 text-white font-bold py-0 px-2 rounded">< Voltar</a>
            </div>
         <div class="mt-5 md:mt-0 md:col-span-2 bg-white">
            <table class="min-w-full divide-y divide-gray-600 w-full">
               <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                ID
               </th>
               <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                   Mês referência
               </th>
               <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                   Valor
               </th>
               <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                   
               </th>
            <?php $__currentLoopData = $pagamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <form method="post" action="<?php echo e(route('pagamentos.update', $contrato->id)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                                <tr class="border-b border-gray-600">
                                    <td scope="col" class="px-6 py-3 bg-gray-900 text-left text-xs font-medium text-white uppercase tracking-wider">
                                        <?php echo e($r->id); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-white bg-gray-900 divide-y divide-gray-600">
                                         <?php echo e(substr_replace($r->mes_referencia, '/', 2, 0)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-white bg-gray-900 divide-y divide-gray-600">
                                       <input type="hidden" name="id" value="<?php echo e($r->id); ?>">
                                       <input type="hidden" name="contrato_id" value="<?php echo e($contrato->id); ?>">
                                       <input type="hidden" name="mes_referencia" value="<?php echo e($r->mes_referencia); ?>">
                                       <input type="number" name="valor" id="valor" class="form-input text-white bg-black my-2 col-span-3 rounded-md shadow-sm mt-1 inline-flex w-half"
                                       value="<?php echo e($r->valor); ?>" />
                                       <?php $__errorArgs = ['valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <p class="text-sm text-red-600"><?php echo e($message); ?>

                                       </p>
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-white bg-gray-900 divide-y divide-gray-600">
                                        <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                        Salvar
                                        </button>
                                     </td>
                                </tr>
                              </form>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </table>   
            </div>
         </div>
   </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\gusta\OneDrive\Desktop\teste-crud\resources\views/pagamentos/edit.blade.php ENDPATH**/ ?>