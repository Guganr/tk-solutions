<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
      <h2 class="font-extrabold text-xl text-white leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    

 <h3 class="mx-10 text-white font-black">Contratos Assinados</h3>
    <div id="chart-contratos" style="height: 300px;"></div>
    <h3 class="mx-10 text-white font-black">Valores Recebidos</h3>
    <div id="chart-valores-recebidos" style="height: 300px;"></div>
    <h3 class="mx-10 text-white font-black">Valores Recebidos e Movimentados</h3>
    <div id="chart-valores-recebidos-movimentados" style="height: 300px;"></div>
    <!-- Charting library -->
    <script src="https://unpkg.com/echarts/dist/echarts.min.js"></script>
    <!-- Chartisan -->
    <script src="https://unpkg.com/@chartisan/echarts/dist/chartisan_echarts.js"></script>
    <!-- Your application script -->
    <script>
      const chartContrato = new Chartisan({
        el: '#chart-contratos',
        url: "<?php echo route('charts.'.'contrato_chart'); ?>",
        hooks: new ChartisanHooks()
            .colors(['#ECC94B', '#4299E1'])
            .datasets([{ type: 'line', fill: false }, { type: 'line', fill: false }]),
      });
      
      const chartValoresRecebidos = new Chartisan({
        el: '#chart-valores-recebidos',
        url: "<?php echo route('charts.'.'valores_recebidos_chart'); ?>",
        hooks: new ChartisanHooks()
            .colors(['#ECC94B', '#4299E1'])
      });
      const chartValoresRecebidosMovimentados = new Chartisan({
        el: '#chart-valores-recebidos-movimentados',
        url: "<?php echo route('charts.'.'valores_recebidos_movimentados_chart'); ?>",
        hooks: new ChartisanHooks()
            .colors(['#ECC94B', '#4299E1'])
      });
    </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\gusta\OneDrive\Desktop\teste-crud\resources\views/dashboard.blade.php ENDPATH**/ ?>