<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            Tickets
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- This example requires Tailwind CSS v2.0+ -->
            <div class="block mb-8">
                <a href="<?php echo e(route('tickets.create')); ?>" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">Criar ticket</a>
            </div>
          <div class="flex flex-col">
            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                        
                        <div class="inline-flex mb-8">
                            <a href="<?php echo e(route('tickets.index', [ 'filter[status]' => '1'])); ?>" class="<?php echo e(str_contains(url()->full(), 'vendedor') ? "bg-white hover:bg-blue-300 hover:text-white text-blue-300 font-bold py-0 px-4 rounded" : "bg-blue-300 hover:bg-white hover:text-blue-300 text-white font-bold py-0 px-4 rounded"); ?>">Aberto</a>
                        </div> 
                        <div class="inline-flex mb-8">
                            <a href="<?php echo e(route('tickets.index',[ 'filter[status]' => '2'])); ?>" class="<?php echo e(str_contains(url()->full(), 'cliente') ? "bg-white hover:bg-blue-300 hover:text-white text-blue-300 font-bold py-0 px-4 rounded" : "bg-blue-300 hover:bg-white hover:text-blue-300 text-white font-bold py-0 px-4 rounded"); ?>">Em andamento</a>
                        </div> 
                        <div class="inline-flex mb-8">
                            <a href="<?php echo e(route('tickets.index',[ 'filter[status]' => '3'])); ?>" class="<?php echo e(str_contains(url()->full(), 'acessor') ? "bg-white hover:bg-blue-300 hover:text-white text-blue-300 font-bold py-0 px-4 rounded" : "bg-blue-300 hover:bg-white hover:text-blue-300 text-white font-bold py-0 px-4 rounded"); ?>">Encerrado</a>
                        </div> 
                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                  <table class="min-w-full divide-y divide-gray-600">
                    <thead class="bg-gray-50">
                      <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                          Identificação do ticket
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                          Mensagem
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                          Data
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                          Status
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-black text-gray-500 bg-black uppercase tracking-wider">
                          Ações
                        </th>
                      </tr>
                    </thead>
                    <tbody class="bg-gray-900 text-white divide-y divide-gray-600">
                      <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                          <?php echo e($ticket->id); ?>

                        </td>

                        <td class="px-6 py-4 whitespace-nowrap">
                          <?php echo e($ticket->mensagem); ?>

                        </td>
                        
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                          <?php echo e(date_create($ticket->created_at)->format("d/m/Y")); ?>

                        </td>
                        
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                        <?php if($userRole->isVendedor() || $userRole->isAdmin()): ?>
                          <form class="inline-block" action="<?php echo e(route('tickets.update', $ticket->id)); ?>"  method="POST" onsubmit="return confirm('Tem certeza?');">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('PUT'); ?>
                          
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                          <input type="hidden" name="responsavel" value="<?php echo e(auth()->user()->id); ?>">
                          <input type="hidden" name="id" value="<?php echo e($ticket->id); ?>">
                          <select name="status" class="bg-black">
                            <?php for($i = 1; $i < 4; $i++): ?>
                              <option <?php echo e($ticket->statusAtual($i)); ?> value="<?php echo e($i); ?>"> <?php echo e($ticket->getStatus($i)); ?> </option>
                            <?php endfor; ?>
                          </select>
                          <?php if($ticket->getStatus($ticket->status) != "Encerrado"): ?>
                            <button type="submit" class="inline-flex text-green-500 hover:text-white ml-4"><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg></button>
                          <?php endif; ?>
                          </form>
                          <?php else: ?>
                          <?php echo e($ticket->getStatus($ticket->status)); ?>

                          <?php endif; ?>
                        </td>
                        
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <a href="<?php echo e(route('tickets.show', $ticket->id)); ?>" class="inline-flex text-blue-300 hover:text-white mb-2 mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                        </a>              
                          <?php if($ticket->getStatus($ticket->status) != "Encerrado"  ||  $userRole->isAcessor()): ?>
                            <a href="<?php echo e(route('replicaCreate', ['replicaId' => $ticket->id])); ?>" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">Responder</a>
                          <?php endif; ?>
                      </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            
            <?php echo e($tickets->links()); ?>

          </div>
         

        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\gusta\OneDrive\Desktop\teste-crud\resources\views/tickets/index.blade.php ENDPATH**/ ?>